/**
 * 
 */
package ox.stackgame.ui;

/**
 * @author danfox
 */
public class RunMode extends Mode {

}
