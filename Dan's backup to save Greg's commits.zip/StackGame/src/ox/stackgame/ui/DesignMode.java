package ox.stackgame.ui;

/**
 * Just a container class for FreeDesignMode and ChallengeMode
 * @author danfox
 *
 */
public abstract class DesignMode extends Mode {

}
